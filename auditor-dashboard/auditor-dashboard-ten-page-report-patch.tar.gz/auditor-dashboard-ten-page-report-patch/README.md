# 10-Page Report

Adds only the 10-page report function. It does not add the Meaningful report.

The system proposes up to 10 pages automatically, with the homepage first and
homepage-linked/shallow/sitemap pages prioritized. Utility URLs are de-prioritized.
You can review and change the selection before execution.

The run:
- is hard-capped at 10 pages;
- does not expand beyond the selected pages;
- defaults to one request at a time with 2000 ms delay;
- obeys robots.txt by default;
- stores `report_scope = ten-page` and the selected URLs.

Apply from `auditor-dashboard`:

```bash
tar -xzf auditor-dashboard-ten-page-report-patch.tar.gz
python3 auditor-dashboard-ten-page-report-patch/apply-ten-page-report-patch.py .
```

Then:

```bash
cd ..
docker compose up -d --build
```
