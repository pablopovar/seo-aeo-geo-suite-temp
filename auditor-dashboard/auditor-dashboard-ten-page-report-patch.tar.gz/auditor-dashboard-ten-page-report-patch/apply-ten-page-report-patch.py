#!/usr/bin/env python3
from pathlib import Path
import re, shutil, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
crawler_path = root/"seo_crawler.py"
crawl_template_path = root/"templates"/"crawl.html"
css_path = root/"static"/"app.css"

for p in (crawler_path, crawl_template_path, css_path):
    if not p.exists():
        raise SystemExit(f"Missing required file: {p}")

patch = Path(__file__).resolve().parent
shutil.copy2(patch/"templates"/"ten_page_select.html", root/"templates"/"ten_page_select.html")

s = crawler_path.read_text()

if "report_scope TEXT NOT NULL DEFAULT 'full'" not in s:
    needle = "        obey_robots INTEGER NOT NULL DEFAULT 1,\n        started_at TEXT,"
    repl = "        obey_robots INTEGER NOT NULL DEFAULT 1,\n        report_scope TEXT NOT NULL DEFAULT 'full',\n        selected_urls_json TEXT,\n        started_at TEXT,"
    if needle not in s:
        raise SystemExit("Could not patch crawl_run schema")
    s = s.replace(needle, repl, 1)

if 'ALTER TABLE crawl_run ADD COLUMN report_scope' not in s:
    needle = "    con.commit()\n\n\ndef add_issue"
    repl = """    cols = {r["name"] for r in con.execute("PRAGMA table_info(crawl_run)").fetchall()}
    if "report_scope" not in cols:
        con.execute("ALTER TABLE crawl_run ADD COLUMN report_scope TEXT NOT NULL DEFAULT 'full'")
    if "selected_urls_json" not in cols:
        con.execute("ALTER TABLE crawl_run ADD COLUMN selected_urls_json TEXT")
    con.commit()


def add_issue"""
    if needle not in s:
        raise SystemExit("Could not add crawl_run migrations")
    s = s.replace(needle, repl, 1)

if "def ten_page_candidates(" not in s:
    marker = "\ndef discover_seed_urls(base_url: str, domain: str):"
    pos = s.find(marker)
    if pos == -1:
        raise SystemExit("Could not locate discovery helper")
    s = s[:pos] + "\n" + (patch/"parts"/"helpers.py.inc").read_text() + s[pos:]

old_sig = "def crawl_worker(run_id, domain, base_url, page_cap, delay_ms, obey_robots, db_factory):"
new_sig = "def crawl_worker(run_id, domain, base_url, page_cap, delay_ms, obey_robots, db_factory, selected_urls=None, follow_links=True):"
if old_sig in s:
    s = s.replace(old_sig, new_sig, 1)
elif new_sig not in s:
    raise SystemExit("Could not patch crawl_worker signature")

old = "    seeds = discover_seed_urls(base_url, domain)\n    queue = list(seeds)\n"
new = "    seeds = list(selected_urls) if selected_urls else discover_seed_urls(base_url, domain)\n    queue = list(seeds)\n"
if old in s:
    s = s.replace(old, new, 1)
elif new not in s:
    raise SystemExit("Could not patch crawl seeds")

old = """                for target in new_links:
                    if len(queued) >= page_cap * 5:
                        break
                    if target not in queued and target not in crawled and same_site(target, domain):
                        queued.add(target)
                        queue.append(target)
"""
new = """                if follow_links:
                    for target in new_links:
                        if len(queued) >= page_cap * 5:
                            break
                        if target not in queued and target not in crawled and same_site(target, domain):
                            queued.add(target)
                            queue.append(target)
"""
if old in s:
    s = s.replace(old, new, 1)
elif new not in s:
    raise SystemExit("Could not patch link expansion")

if "def ten_page_select(" not in s:
    anchor = '    @app.post("/d/<domain>/crawl/run")\n    def seo_crawl_run(domain):'
    pos = s.find(anchor)
    if pos == -1:
        raise SystemExit("Could not locate crawler run route")
    s = s[:pos] + (patch/"parts"/"routes.py.inc").read_text() + "\n" + s[pos:]

compile(s, str(crawler_path), "exec")
crawler_path.write_text(s)

tpl = crawl_template_path.read_text()
if "ten_page_select" not in tpl:
    marker = '<section class="panel">\n  <form method="post" action="{{ url_for(\'seo_crawl_run\', domain=site.domain) }}"'
    insert = """<section class="panel">
  <div class="report-scope-actions">
    <a class="button primary" href="{{ url_for('ten_page_select', domain=site.domain) }}">10-Page Report</a>
    <span>Automatically propose 10 pages, review the selection, then run exactly those pages.</span>
  </div>
</section>

"""
    if marker not in tpl:
        raise SystemExit("Could not locate crawl form in crawl.html")
    tpl = tpl.replace(marker, insert + marker, 1)
crawl_template_path.write_text(tpl)

css = css_path.read_text()
extra = """
/* 10-page report */
.ten-page-summary{margin:0 0 12px;font-size:14px}
.ten-page-controls{display:flex;gap:16px;align-items:end;flex-wrap:wrap;margin-top:16px}
.ten-page-controls label{display:flex;gap:6px;align-items:center}
.ten-page-controls label:first-child{flex-direction:column;align-items:flex-start}
.ten-page-controls input[type=number]{width:120px}
.report-scope-actions{display:flex;gap:12px;align-items:center;flex-wrap:wrap}
"""
if "/* 10-page report */" not in css:
    css += "\n" + extra
css_path.write_text(css)

print("10-page report patch applied.")
print("Meaningful report was not added.")
print("10-page runs default to 2000 ms delay and never exceed 10 selected pages.")
