#!/usr/bin/env python3
from pathlib import Path
import re, shutil, sys

root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
app_path=root/"app.py"
base_path=root/"templates"/"base.html"
for p in (app_path,base_path):
    if not p.exists(): raise SystemExit(f"Missing required file: {p}")
patch=Path(__file__).resolve().parent
for name in ("dataforseo_connector.py","dataforseo_extension.py"):
    shutil.copy2(patch/name,root/name)
shutil.copy2(patch/"templates"/"dataforseo.html",root/"templates"/"dataforseo.html")
app=app_path.read_text()

if "register_dataforseo_extension(app" not in app:
    block="\n# PB extension: DataForSEO\nfrom dataforseo_extension import register_dataforseo_extension\nregister_dataforseo_extension(app, research_db, get_site, get_sites)\n\n"
    runner=re.search(r'(?m)^if __name__\s*==\s*["\']__main__["\']\s*:',app)
    pos=runner.start() if runner else len(app)
    app=app[:pos]+block+app[pos:]

# Fix the current zero-page audit failure mode without guessing about other failures.
if "def start_audit_run(" in app and "PB_AUDIT_ZERO_PAGE_FALLBACK" not in app:
    start=app.find("def start_audit_run(")
    ends=[x for x in (app.find("\ndef ",start+5),app.find("\n@app.",start+5)) if x!=-1]
    end=min(ends) if ends else len(app)
    seg=app[start:end]
    first_nl=seg.find("\n")
    if first_nl!=-1 and "pages" in seg[:first_nl]:
        guard=(
            "    # PB_AUDIT_ZERO_PAGE_FALLBACK\n"
            "    if not pages:\n"
            "        try:\n"
            "            sync_site_pages(domain)\n"
            "            with research_db() as _con:\n"
            "                pages = _con.execute(\"SELECT id,url,path FROM site_page WHERE domain=? ORDER BY path COLLATE NOCASE\", (domain,)).fetchall()\n"
            "        except Exception:\n"
            "            pages = pages or []\n"
            "    if not pages:\n"
            "        pages = [{\"id\": None, \"url\": \"https://\" + domain.rstrip(\"/\") + \"/\", \"path\": \"/\"}]\n"
        )
        seg=seg[:first_nl+1]+guard+seg[first_nl+1:]
        app=app[:start]+seg+app[end:]

compile(app,str(app_path),"exec")
app_path.write_text(app)
base=base_path.read_text()
if "dataforseo_extension" not in base:
    link="\n<a class=\"{% if request.endpoint and request.endpoint.startswith('dataforseo_') %}active{% endif %}\" href=\"{% if site is defined and site %}{{ url_for('dataforseo_extension', domain=site.domain) }}{% else %}#{% endif %}\">Extensions</a>\n"
    pos=base.find("</nav>")
    if pos==-1: pos=base.find("</header>")
    if pos==-1: raise SystemExit("Could not locate navigation insertion point.")
    base=base[:pos]+link+base[pos:]
base_path.write_text(base)
print("DataForSEO extension installed.")
print("Default project state: disabled.")
print("Default limit: 2 calls/report, 10 items/report.")
print("Kill switch gate installed.")
print("Audit zero-page fallback: "+("installed" if "PB_AUDIT_ZERO_PAGE_FALLBACK" in app else "not applied"))
