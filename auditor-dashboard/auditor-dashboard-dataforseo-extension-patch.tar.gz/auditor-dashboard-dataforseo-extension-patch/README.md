# DataForSEO Extension

Modular DataForSEO connector.

Credentials:
- `DATAFORSEO_LOGIN`
- `DATAFORSEO_PASSWORD`

Hard kill switch:
- `DATAFORSEO_KILL_SWITCH=1`

Defaults per project:
- disabled
- max 2 API calls/report
- max 10 items/report

Minimal pull only:
1. DataForSEO Labs Google Domain Rank Overview
2. DataForSEO Labs Google Ranked Keywords, tiny sample

The UI provides project enable/disable, pulling limits, an Enabled Features placeholder,
a global kill switch, usage/cost totals, and a manual minimal pull.

The installer also adds a guard for the observed zero-page audit failure mode when
`start_audit_run()` is present.

Apply:

```bash
tar -xzf auditor-dashboard-dataforseo-extension-patch.tar.gz
python3 auditor-dashboard-dataforseo-extension-patch/apply-dataforseo-extension-patch.py .
```
