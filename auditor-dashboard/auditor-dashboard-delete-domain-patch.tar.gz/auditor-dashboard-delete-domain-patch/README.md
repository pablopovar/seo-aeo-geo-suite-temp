# Delete Domain

Adds a Delete Domain function.

Deletion removes the dashboard domain and its dashboard-owned data, but does not delete external GSC/GA4 connections.

It also suppresses OpenGSC auto-import for the deleted hostname so the domain does not immediately reappear. Explicitly adding the domain again removes the suppression when the independent-domain integration is present.

Apply from `auditor-dashboard`:

```bash
tar -xzf auditor-dashboard-delete-domain-patch.tar.gz
python3 auditor-dashboard-delete-domain-patch/apply-delete-domain-patch.py .
```
