#!/usr/bin/env python3
from pathlib import Path
import re
import shutil
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
app_path = root / "app.py"
base_path = root / "templates" / "base.html"

for p in (app_path, base_path):
    if not p.exists():
        raise SystemExit(f"Missing required dashboard file: {p}")

patch = Path(__file__).resolve().parent
shutil.copy2(patch / "delete_domain.py", root / "delete_domain.py")
shutil.copy2(patch / "templates" / "domain_delete.html", root / "templates" / "domain_delete.html")

app = app_path.read_text()

if "register_delete_domain(app" not in app:
    block = (
        "\n# PB delete-domain feature\n"
        "from delete_domain import register_delete_domain\n"
        "register_delete_domain(app, research_db, get_site, get_sites)\n\n"
    )
    runner = re.search(r'(?m)^if __name__\s*==\s*["\']__main__["\']\s*:', app)
    pos = runner.start() if runner else len(app)
    app = app[:pos] + block + app[pos:]

# Honor domain suppression during OpenGSC auto-import.
if "def sync_dashboard_domains_from_opengsc(" in app:
    start = app.find("def sync_dashboard_domains_from_opengsc(")
    end = app.find("\ndef ", start + 5)
    if end == -1:
        end = len(app)
    segment = app[start:end]

    if "_suppressed_domains" not in segment:
        sig = "def sync_dashboard_domains_from_opengsc():\n"
        injected = (
            "def sync_dashboard_domains_from_opengsc():\n"
            "    with research_db() as _suppression_con:\n"
            "        _suppression_con.execute(\"\"\"\n"
            "            CREATE TABLE IF NOT EXISTS domain_suppression (\n"
            "                domain TEXT PRIMARY KEY COLLATE NOCASE,\n"
            "                suppressed_at TEXT NOT NULL\n"
            "            )\n"
            "        \"\"\")\n"
            "        _suppressed_domains = {\n"
            "            r[\"domain\"].lower()\n"
            "            for r in _suppression_con.execute(\n"
            "                \"SELECT domain FROM domain_suppression\"\n"
            "            ).fetchall()\n"
            "        }\n"
            "        _suppression_con.commit()\n"
        )
        app = app.replace(sig, injected, 1)

        needle = (
            '            domain=_opengsc_site_domain(gsc)\n'
            '            gsc_id=_site_value(gsc,"id")\n'
            '            if not domain or not gsc_id:\n'
            '                continue\n'
        )
        if needle in app:
            app = app.replace(
                needle,
                needle
                + '            if domain.lower() in _suppressed_domains:\n'
                + '                continue\n',
                1
            )

# Explicit Add Domain removes suppression so it can be added again.
if (
    "def create_dashboard_domain(" in app
    and "DELETE FROM domain_suppression WHERE domain" not in app
):
    start = app.find("def create_dashboard_domain(")
    end = app.find("\ndef ", start + 5)
    if end == -1:
        end = len(app)
    segment = app[start:end]
    target = "sync_dashboard_domains_from_opengsc()"
    rel = segment.find(target)

    if rel != -1:
        abspos = start + rel
        line_start = app.rfind("\n", 0, abspos) + 1
        raw_prefix = app[line_start:abspos]
        indent = raw_prefix[:len(raw_prefix)-len(raw_prefix.lstrip())]

        snippet = (
            indent + "with research_db() as _suppression_con:\n"
            + indent + "    _suppression_con.execute(\n"
            + indent + '        "DELETE FROM domain_suppression WHERE domain=? COLLATE NOCASE",\n'
            + indent + "        (domain,)\n"
            + indent + "    )\n"
            + indent + "    _suppression_con.commit()\n"
        )

        app = app[:abspos] + snippet + app[abspos:]

compile(app, str(app_path), "exec")
app_path.write_text(app)

base = base_path.read_text()

if "domain_delete_confirm" not in base:
    link = """
<a class="{% if request.endpoint in ['domain_delete_confirm','domain_delete'] %}active{% endif %}"
   href="{% if site is defined and site %}{{ url_for('domain_delete_confirm', domain=site.domain) }}{% else %}#{% endif %}">
  Delete Domain
</a>
"""
    pos = base.find("</nav>")
    if pos == -1:
        pos = base.find("</header>")
    if pos == -1:
        raise SystemExit("Could not locate navigation insertion point in base.html")
    base = base[:pos] + link + base[pos:]

base_path.write_text(base)

print("Delete Domain installed.")
print("Dashboard data and registry record are removed.")
print("External GSC/GA4 connections are untouched.")
print("OpenGSC auto-import suppression is enabled when supported.")
