# Delete Domain v2

Corrected patch for the current compact dashboard app.py.

This version deliberately does not patch `create_dashboard_domain()`, which caused
the previous indentation failure.

It:
- adds a Delete Domain confirmation page and POST action;
- removes dashboard-owned domain data;
- leaves external GSC/GA4 connections alone;
- records a suppression row;
- makes OpenGSC auto-import skip suppressed domains.

Apply from `auditor-dashboard`:

```bash
tar -xzf auditor-dashboard-delete-domain-patch-v2.tar.gz
python3 auditor-dashboard-delete-domain-patch-v2/apply-delete-domain-patch-v2.py .
```
