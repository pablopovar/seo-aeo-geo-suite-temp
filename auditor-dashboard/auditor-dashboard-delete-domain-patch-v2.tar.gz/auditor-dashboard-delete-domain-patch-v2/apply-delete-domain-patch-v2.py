#!/usr/bin/env python3
from pathlib import Path
import re, shutil, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
app_path = root/"app.py"
base_path = root/"templates"/"base.html"
for p in (app_path, base_path):
    if not p.exists():
        raise SystemExit(f"Missing required file: {p}")

patch = Path(__file__).resolve().parent
shutil.copy2(patch/"delete_domain.py", root/"delete_domain.py")
shutil.copy2(patch/"templates"/"domain_delete.html", root/"templates"/"domain_delete.html")

app = app_path.read_text()

# 1) Register delete feature. No transformation inside create_dashboard_domain().
if "register_delete_domain(app" not in app:
    block = (
        "\n# PB delete-domain feature\n"
        "from delete_domain import register_delete_domain\n"
        "register_delete_domain(app, research_db, get_site, get_sites)\n\n"
    )
    runner = re.search(r'(?m)^if __name__\s*==\s*["\']__main__["\']\s*:', app)
    pos = runner.start() if runner else len(app)
    app = app[:pos] + block + app[pos:]

# 2) Make OpenGSC import skip suppressed domains, using the exact current helper shape.
if "def sync_dashboard_domains_from_opengsc():" in app and "_suppressed_domains" not in app:
    sig = "def sync_dashboard_domains_from_opengsc():\n"
    injected = (
        "def sync_dashboard_domains_from_opengsc():\n"
        "    with research_db() as _suppression_con:\n"
        "        _suppression_con.execute(\"\"\"\n"
        "            CREATE TABLE IF NOT EXISTS domain_suppression (\n"
        "                domain TEXT PRIMARY KEY COLLATE NOCASE,\n"
        "                suppressed_at TEXT NOT NULL\n"
        "            )\n"
        "        \"\"\")\n"
        "        _suppressed_domains = {\n"
        "            r[\"domain\"].lower()\n"
        "            for r in _suppression_con.execute(\"SELECT domain FROM domain_suppression\").fetchall()\n"
        "        }\n"
        "        _suppression_con.commit()\n"
    )
    app = app.replace(sig, injected, 1)

    needle = (
        '            domain=_opengsc_site_domain(gsc)\n'
        '            gsc_id=_site_value(gsc,"id")\n'
        '            if not domain or not gsc_id:\n'
        '                continue\n'
    )
    if needle not in app:
        raise SystemExit("Could not locate exact OpenGSC sync loop; no files written.")
    app = app.replace(
        needle,
        needle + '            if domain.lower() in _suppressed_domains:\n                continue\n',
        1
    )

# Validate app before writing.
compile(app, str(app_path), "exec")
app_path.write_text(app)

base = base_path.read_text()
if "domain_delete_confirm" not in base:
    link = """
<a class="{% if request.endpoint in ['domain_delete_confirm','domain_delete'] %}active{% endif %}"
   href="{% if site is defined and site %}{{ url_for('domain_delete_confirm', domain=site.domain) }}{% else %}#{% endif %}">
  Delete Domain
</a>
"""
    pos = base.find("</nav>")
    if pos == -1:
        pos = base.find("</header>")
    if pos == -1:
        raise SystemExit("Could not locate navigation insertion point.")
    base = base[:pos] + link + base[pos:]
base_path.write_text(base)

print("Delete Domain v2 installed.")
print("No modification was made inside create_dashboard_domain().")
