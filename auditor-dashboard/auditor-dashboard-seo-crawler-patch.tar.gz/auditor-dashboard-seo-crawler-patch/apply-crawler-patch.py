#!/usr/bin/env python3
from pathlib import Path
import re
import shutil
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
app_path = root / "app.py"
base_path = root / "templates" / "base.html"
css_path = root / "static" / "app.css"

for p in (app_path, base_path, css_path):
    if not p.exists():
        raise SystemExit(f"Missing required dashboard file: {p}")

patch = Path(__file__).resolve().parent
shutil.copy2(patch / "crawler" / "seo_crawler.py", root / "seo_crawler.py")
shutil.copy2(patch / "templates" / "crawl.html", root / "templates" / "crawl.html")

app = app_path.read_text()

# Register crawler after all dashboard helpers exist, but before the dev-server runner.
if "register_crawler(app" not in app:
    block = """
# PB SEO crawler
from seo_crawler import register_crawler
app.config["PB_GET_SITES"] = get_sites
register_crawler(app, research_db, get_site)

"""
    runner = re.search(r'(?m)^if __name__\s*==\s*["\']__main__["\']\s*:', app)
    if runner:
        pos = runner.start()
        app = app[:pos] + block + app[pos:]
    else:
        # In case app.py has no __main__ runner, registration can safely be appended.
        app = app.rstrip() + "\n\n" + block

compile(app, str(app_path), "exec")
app_path.write_text(app)

base = base_path.read_text()
if "url_for('seo_crawl'" not in base:
    link = """
<a class="{% if request.endpoint in ['seo_crawl','seo_crawl_run','seo_crawl_status'] %}active{% endif %}"
   href="{% if site is defined and site %}{{ url_for('seo_crawl', domain=site.domain) }}{% else %}#{% endif %}">
  Crawl
</a>
"""
    pos = base.find("</nav>")
    if pos == -1:
        pos = base.find("</header>")
    if pos == -1:
        raise SystemExit("Could not locate navigation insertion point in base.html")
    base = base[:pos] + link + base[pos:]
base_path.write_text(base)

css = css_path.read_text()
extra = (patch / "static" / "crawler.css.inc").read_text()
if "/* SEO crawler */" not in css:
    css += "\n" + extra
css_path.write_text(css)

print("SEO crawler patch applied.")
print("New dashboard route: /d/<domain>/crawl")
print("Crawler is sitemap-first, same-domain, sequential, robots-aware, and persisted.")
