# SEO Crawler Patch

Adds a persistent public-site SEO crawler to the dashboard.

## What it does

- sitemap-first discovery (`/sitemap.xml`, then `/sitemap_index.xml`)
- falls back to the homepage when no sitemap is usable
- follows same-domain internal links
- configurable page cap
- configurable polite delay
- robots.txt aware
- sequential crawling
- stores crawl runs and page observations
- best-effort adds newly discovered URLs to existing `site_page`
- detects common crawl-derived SEO issues
- works without GSC

## Data stored

`crawl_run`
- status
- page cap
- delay
- robots setting
- discovered/crawled/failed counts
- timestamps/errors

`crawl_page`
- requested/final URL
- status
- content type/size
- response time
- title/meta description
- canonical
- robots meta
- language
- viewport
- H1/H2
- visible word count
- internal/external link counts
- image count / missing-alt count
- schema types
- hreflang
- Open Graph
- indexability
- robots allowance
- fetch/parser error

`crawl_link`
- source
- target
- internal/external
- rel

`crawl_issue`
- HTTP errors
- redirects
- missing/short/long titles
- missing descriptions
- missing/multiple H1
- missing canonical
- missing viewport
- missing image alt
- no JSON-LD schema
- thin visible content
- noindex
- robots-blocked
- broken crawled internal links

## Apply

From `auditor-dashboard`:

```bash
tar -xzf auditor-dashboard-seo-crawler-patch.tar.gz
python3 auditor-dashboard-seo-crawler-patch/apply-crawler-patch.py .
```

Then rebuild from the unified suite root:

```bash
cd ..
docker compose up -d --build
```

Open the dashboard and use **Crawl** for a selected domain.

## Current scope

This is intentionally a V1 crawler, not a Screaming Frog replacement. It does not yet provide:
- browser-rendered JavaScript crawling
- external backlink data
- PageSpeed/Core Web Vitals
- search-volume/ranking estimates from third-party providers
- durable job resumption after a dashboard process restart
