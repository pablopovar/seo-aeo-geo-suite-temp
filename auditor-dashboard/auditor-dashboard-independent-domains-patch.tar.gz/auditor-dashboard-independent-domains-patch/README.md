# Independent Domain Registry

The dashboard becomes the source of truth for domains. OpenGSC/GSC is optional.

Adding a domain:
1. creates a dashboard-owned domain record;
2. discovers sitemap pages;
3. populates `site_page`;
4. auto-links a matching OpenGSC site if present;
5. otherwise displays `GSC missing` and leaves GSC values empty.

If the domain is connected to OpenGSC later, the matching site is linked automatically.

Apply from `auditor-dashboard`:

```bash
tar -xzf auditor-dashboard-independent-domains-patch.tar.gz
python3 auditor-dashboard-independent-domains-patch/apply-independent-domains-patch.py .
```

Then rebuild from the unified suite root:

```bash
cd ..
docker compose up -d --build
```
