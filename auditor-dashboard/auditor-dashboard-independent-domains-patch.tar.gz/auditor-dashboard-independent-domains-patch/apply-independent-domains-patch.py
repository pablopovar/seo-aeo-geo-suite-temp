#!/usr/bin/env python3
from pathlib import Path
import re,shutil,sys

root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
app_path=root/"app.py"
base_path=root/"templates"/"base.html"
css_path=root/"static"/"app.css"

for p in [app_path,base_path,css_path]:
    if not p.exists():
        raise SystemExit(f"Missing dashboard file: {p}")

patch=Path(__file__).resolve().parent
parts=patch/"parts"
shutil.copy2(patch/"templates"/"domain_new.html",root/"templates"/"domain_new.html")

s=app_path.read_text()

if "CREATE TABLE IF NOT EXISTS dashboard_domain" not in s:
    start=s.find("def research_db():")
    marker="    con.commit()\n    return con\n"
    pos=s.find(marker,start)
    if pos==-1:
        raise SystemExit("Could not locate research_db() schema end")
    s=s[:pos]+(parts/"schema.py.inc").read_text()+s[pos:]

if "def _opengsc_get_sites(" not in s:
    if "def get_sites(" not in s:
        raise SystemExit("Could not find existing get_sites()")
    s=s.replace("def get_sites(","def _opengsc_get_sites(",1)

if "def _opengsc_get_site(" not in s and "def get_site(" in s:
    s=s.replace("def get_site(","def _opengsc_get_site(",1)

if "def normalize_dashboard_domain(" not in s:
    first=s.find("\n@app.")
    if first==-1:
        raise SystemExit("Could not locate first route")
    s=s[:first]+"\n"+(parts/"helpers.py.inc").read_text()+"\n"+s[first:]

if "def domain_new(" not in s:
    first=s.find('\n@app.route("/d/<domain>')
    if first==-1:
        first=s.find("\n@app.")
    if first==-1:
        raise SystemExit("Could not locate route insertion point")
    s=s[:first]+"\n"+(parts/"route.py.inc").read_text()+"\n"+s[first:]

if "def gsc_rows_for_domain(domain):" in s and 'if site.get("gsc_missing")' not in s:
    pat=re.compile(r'def gsc_rows_for_domain\(domain\):\n(\s+)site = get_site\(domain\)')
    def repl(m):
        i=m.group(1)
        return 'def gsc_rows_for_domain(domain):\n'+i+'site = get_site(domain)\n'+i+'if site.get("gsc_missing"):\n'+i+'    return []'
    s,_=pat.subn(repl,s,count=1)

compile(s,str(app_path),"exec")
app_path.write_text(s)

base=base_path.read_text()

if "url_for('domain_new')" not in base:
    link='\n<a class="{% if request.endpoint == \'domain_new\' %}active{% endif %}" href="{{ url_for(\'domain_new\') }}">+ Domain</a>\n'
    pos=base.find("</nav>")
    if pos==-1:
        pos=base.find("</header>")
    if pos==-1:
        raise SystemExit("Could not locate nav/header")
    base=base[:pos]+link+base[pos:]

banner='\n{% if site is defined and site and site.gsc_missing %}\n<div class="gsc-missing-banner">GSC missing</div>\n{% endif %}\n'
if "gsc-missing-banner" not in base:
    block="{% block content %}"
    if block not in base:
        raise SystemExit("Could not locate content block")
    base=base.replace(block,banner+"\n"+block,1)

base_path.write_text(base)

css=css_path.read_text()
extra='\n/* Independent dashboard domains */\n.gsc-missing-banner{display:inline-block;margin:10px 0 0;padding:4px 8px;border:1px solid #d8a63d;border-radius:999px;font-size:12px;font-weight:600;background:#fff8e6;color:#76530c}\n.add-domain-panel{max-width:760px}\n.add-domain-panel input[name="domain"]{min-width:360px}\n'
if "/* Independent dashboard domains */" not in css:
    css+="\n"+extra
css_path.write_text(css)

print("Independent-domain patch applied.")
print("Dashboard now owns the domain registry.")
print("OpenGSC/GSC is optional and auto-linked when available.")
print("Domains without GSC remain usable; GSC-specific values resolve empty.")
